//2. Dada una lista de números, imprime el resultado de la suma de todos.

fun main(){
    val listas= mutableListOf(6,2,3,4,1)
  
    var suma=0
    for (elemento in listas) {
        suma+=elemento
      
    }
    println ("$suma")
  }


// se crea un arreglo de tamaño 3 que contiene los valores 0, 2 y 4,
//  utilizando el constructor Array() 
// val otroArreglo = Array(3) { i -> i * 2 }
// se crea un arreglo de enteros con los valores del 1 al 5 
// usando la función arrayOf().
// val miArreglo = arrayOf(1, 2, 3, 4, 5)


//se accede a los elementos del arreglo
// val miArreglo = arrayOf("hola", "mundo", "!")
// println(miArreglo[0])  imprime "hola"
// println(miArreglo[1])  imprime "mundo"
// println(miArreglo[2])  imprime "!"



// se cambia el valor del segundo elemento 
// del arreglo de 2 a 4.
// val miArreglo = arrayOf(1, 2, 3)
// miArreglo[1] = 4
// println(miArreglo[1]) // imprime "4"



// val miArreglo = arrayOf(1, 2, 3)

// se usa un bucle for para iterar por todos los elementos 
// del arreglo usando el tamaño del arreglo para limitar el bucle.
// for (i in 0 until miArreglo.size) {
//     println(miArreglo[i])
// }


// se usa un bucle forEach para iterar por todos los elementos 
// del arreglo sin tener que preocuparse por el índice.
// miArreglo.forEach { elemento ->
//     println(elemento)
// }





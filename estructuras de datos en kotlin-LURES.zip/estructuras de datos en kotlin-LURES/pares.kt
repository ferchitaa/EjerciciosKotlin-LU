// // se crea el primer par
// val par1=Pair ("hola", 123)
// // se crea el segundo par
// val par2= "adios" to 456
// //en ambos casos, se crea un par que contiene una cadena y un numero.



// //se imprime los dos elementos par mencionados anteriormente.
// println(par1.first)//imprime "hola"
// println(par1.second)//imprime "123"


// //se crea un nuevo par con los valores actualizados
// val par3 = par1.copy(second = 456)
// println(par3) //imprime "(hola, 456)"







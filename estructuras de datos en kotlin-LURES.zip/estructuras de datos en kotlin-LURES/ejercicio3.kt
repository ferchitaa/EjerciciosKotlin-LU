//3. Dado un conjunto de palabras, utilizar una condición para tener acceso  a un elemento y luego imprime esa lista.

fun main(){
    val conjuntos = setOf("tv","portatil","telefono","moto")
  
    if (conjuntos.contains("carro")){
         println("este conjunto tiene un carro.")
    }else {
         println("este conjunto no tiene un carro.")   
    }
    for (i in conjuntos) {
        println (i)
    }
    
  }

// // se crea un conjunto de números 
// // enteros con tres elementos utilizando la función setOf().
// val miConjunto = setOf(1, 2, 3)
// // se crea un conjunto de cadenas
// //  de texto utilizando el constructor Set().
// val otroConjunto = Set.of("hola", "mundo", "!")



// //se accede a los elementos del conjunto
// val miConjunto = setOf(1, 2, 3)
// // se utiliza la función contains() 
// // para verificar si un elemento está presente en el conjunto.
// println(miConjunto.contains(2)) // imprime true
// println(miConjunto.contains(4)) // imprime false




// // Creando un conjunto mutable
// val miConjuntoMutable = mutableSetOf(1, 2, 3)
// // Agregando un nuevo elemento al conjunto
// miConjuntoMutable.add(4)
// // Eliminando un elemento del conjunto
// miConjuntoMutable.remove(2)
// // En este ejemplo, se crea un conjunto mutable utilizando 
// // la función mutableSetOf() y se agrega un nuevo elemento 
// // y se elimina un elemento del conjunto.
// println(miConjuntoMutable) // imprime "[1, 3, 4]"


// // se accede a los elementos del conjunto
// val miConjunto = setOf(1, 2, 3)
// // se usa un bucle for 
// // para iterar por todos los elementos del conjunto.
// for (elemento in miConjunto) {
//     println(elemento)
// }
// // se usa un bucle forEach
// //  para iterar por todos los elementos del conjunto.
// miConjunto.forEach { elemento ->
//     println(elemento)
// }





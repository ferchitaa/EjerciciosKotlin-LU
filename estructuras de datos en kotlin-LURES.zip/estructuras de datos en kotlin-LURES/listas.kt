
// se crea una lista de tamaño 3 que contiene 
// las cadenas "0", "1" y "4", utilizando el constructor List()
// val otraLista = List(3) { i -> (i * i).toString() }
// se crea una lista de cadenas de 
// texto con tres elementos utilizando la función listOf().
// val miLista = listOf("hola", "mundo", "!")



//se accede a los elementos de la lista
// val miLista = listOf("hola", "mundo", "!")
// println(miLista[0]) // imprime "hola"
// println(miLista[1]) // imprime "mundo"
// println(miLista[2]) // imprime "!"



// // se crea una lista mutable
// val miListaMutable = mutableListOf("hola", "mundo", "!")
// // se modifica un elemento de la lista
// miListaMutable[1] = "Kotlin"
// // se agrega un nuevo elemento a la lista
// miListaMutable.add("es genial")
// // se elimina un elemento de la lista
// miListaMutable.removeAt(0)
// // por ultimo imprime "[Kotlin, es genial]"
// // En este ejemplo, se crea una lista mutable utilizando la
// //  función mutableListOf() y se modifica un elemento, se agrega
// //  un nuevo elemento y se elimina el primer elemento de la lista.
//  println(miListaMutable)



// // se accede a los elementos de la lista
// val miLista = listOf("hola", "mundo", "!")
// // se usa un bucle for para iterar por todos los elementos 
// // de la lista utilizando el tamaño de la lista para limitar el bucle.
// for (i in 0 until miLista.size) {
//     println(miLista[i])
// }
// // se usa un bucle forEach para iterar por todos los elementos 
// // de la lista sin tener que preocuparse por el índice.
// miLista.forEach { elemento ->
//     println(elemento)
// }








//1. Dado un arreglo de 5 posiciones y luego imprímalos.

fun main(){
  val arrays= arrayOf(1,2,3,4,5)

  for (i in arrays.indices) {
    println (arrays[i])
  }
}

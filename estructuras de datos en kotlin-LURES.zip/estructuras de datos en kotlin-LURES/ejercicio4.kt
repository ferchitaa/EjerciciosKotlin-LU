//4. Dado un mapa de nombres asígneles un valor e imprima todos los nombres con dicho valor.

fun main(){
    val mapas= hashMapOf("luisa" to 1,"portatil" to 2,"restrepo" to 3,"moto" to 4)
  
    for ((key,value) in mapas.entries) {
        println ("$key = $value")
    }
    
  }

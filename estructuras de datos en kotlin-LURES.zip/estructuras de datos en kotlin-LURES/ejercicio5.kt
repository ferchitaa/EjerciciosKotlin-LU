//5. Dado un par de elementos , acceder a un solo elemento e imprime el resultado .

fun main (){
    val pares = Pair("cali", 2003)
    val segundopar = pares.second

    println("$segundopar")
}
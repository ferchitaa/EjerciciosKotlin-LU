
// se crea un mapa de números enteros a 
// cadenas de texto utilizando el constructor mutableMapOf().
// val miMapa = mapOf("a" to 1, "b" to 2, "c" to 3)
// se crea un mapa de cadenas de 
// texto a números enteros utilizando la función mapOf().
// val otroMapa = mutableMapOf(1 to "uno", 2 to "dos", 3 to "tres")



// //se accede a los elementos del mapa
// val miMapa = mapOf("a" to 1, "b" to 2, "c" to 3)
// println(miMapa["b"]) // imprime "2"
// // En este ejemplo, se utiliza el operador de 
// // corchetes [] para acceder al valor asociado con la clave "b".



// // Creando un mapa mutable
// val miMapaMutable = mutableMapOf("a" to 1, "b" to 2, "c" to 3)
// // Agregando un nuevo par clave-valor al mapa
// miMapaMutable["d"] = 4
// // Modificando el valor asociado con una clave existente
// miMapaMutable["b"] = 5
// // Eliminando un par clave-valor del mapa
// miMapaMutable.remove("c")
// println(miMapaMutable) // imprime "{a=1, b=5, d=4}"
// //  En este ejemplo, se crea un mapa mutable utilizando la función 
// //  mutableMapOf() y se agrega un nuevo par clave-valor, se modifica el 
// //  valor asociado con una clave existente y se elimina un par 
// // clave-valor del mapa.



// val miMapa = mapOf("a" to 1, "b" to 2, "c" to 3)
// // se usa un bucle for para iterar por todos 
// // los pares clave-valor del mapa.
// for ((clave, valor) in miMapa) {
//     println("La clave $clave tiene el valor $valor")
// }
// // se usa un bucle forEach para iterar por todos los pares clave-valor
// //  del mapa.
// miMapa.forEach { (clave, valor) ->
//     println("La clave $clave tiene el valor $valor")
// }







